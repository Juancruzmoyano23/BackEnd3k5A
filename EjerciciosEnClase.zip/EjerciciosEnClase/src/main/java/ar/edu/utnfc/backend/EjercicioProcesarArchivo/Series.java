package ar.edu.utnfc.backend.EjercicioProcesarArchivo;


public class Series {

    // titulo (String), genero (String), plataforma (String), anio (int), temporadas (int), calificacion

    private String titulo, genero, plataforma;
    private int anio, temporada;
    private double calificacion;

    public Series(String t, String g, String p, int a, double c, int temp){
        this.titulo = t;
        this.anio = a;
        this.calificacion = c;
        this.genero = g;
        this.temporada = temp;
        this.plataforma = p;

    }

    public String getTtitulo(){return titulo;}

    public Integer getAnio(){return anio;}

    public Double getCalificacion(){return calificacion;}

    public String getGenero(){return genero;}

    public String getPlataforma(){return plataforma;}

    public Integer getTemporada(){return temporada;}


    @Override
    public String toString(){
        return "Titulo: " + titulo + " Genero: " + genero + " Plataforma: " + plataforma + " Año: " + anio + " Calificacion: " + calificacion + " Temporada: " + temporada;
    }

    public String toCsv(Series s) {

        String columnas;

        for (Series serie : s) {
            columnas = serie.getTtitulo() + "," + serie.getGenero() + "," + serie.getPlataforma() + "," + serie.getAnio() + "," + serie.getTemporada() + "," + serie.getCalificacion();
        }

        return columnas;
    }
}
