package ar.edu.utnfc.backend.EjercicioProcesarArchivo;

import java.io.BufferedReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;

public class Main{

    public static void main(String[] args){

        // path csv = Path.of("./resource/archivo.csv");

        // variables
        int contador = 0;

        // lectura del archivo
        try (BufferedReader lector = Files.newBufferedReader(
                Path.of("data/archivo.csv"), StandardCharsets.UTF_8)) {

                    String linea;

                    // la primera linea es el encabezado, por lo que se lee y se descarta
                    linea = lector.readLine();

                    ArrayList<Series> seriesArray = new ArrayList<>();

                    while ((linea = lector.readLine()) != null) {
                        contador++;

                        String[] columnas = linea.split(",");

                        String titulo = columnas[0];
                        String genero = columnas[1];
                        String plataforma = columnas[2];
                        int anio = Integer.parseInt(columnas[3]);
                        double calificacion = Double.parseDouble(columnas[5]);
                        int temporada = Integer.parseInt(columnas[4]);

                        Series series = new Series(titulo, genero, plataforma, anio, calificacion, temporada);

                        seriesArray.add(series);
                    }

                    System.out.println("Las cantidad totales de filas son: " + (contador - 1));

                    for (Series s : seriesArray){
                        System.out.println(s.toString());
                    }


        } catch (IOException e) {
            throw new RuntimeException(e);
        }




    }
}

